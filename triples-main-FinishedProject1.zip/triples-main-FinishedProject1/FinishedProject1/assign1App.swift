//
//  assign1App.swift
//  assign1
//
//  Created by Ndenko Benanzea-Fontem on 2/25/23.
//

import SwiftUI

@main
struct assign1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
